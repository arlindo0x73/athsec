------------------------------
# TITULO - 
Nos colocamos o seu negocio sob nossa proteção

## Descricao:
Damos às organizações a confiança de que estão preparadas para combater os adversários modernos, Assumindo com responsabilidade a capacidade de protegr as informaçoes privilegiadas nas organizações que assessoramos.

----------------------------------

CONTACTOS

-----------------------------------

# TITULO - 
Repense na sua Segurança

## Descricao:
Na ATHSec trabalhamos de forma escalável e adaptátiva, combinamos a nossa inteligência, estratégia e alinhamos com os objetivos do seu negócio, ajudamos as organizações a reduzir o tempo de inatividade, maximizar a capacidade de produção, otimizar o custo de manutenção dos ativos e acelerar a sua transformação digital, com a Cyber ​​​​Defense Enterprise ajudamos as empresas diante da <b>incerteza!</b>

---------------------------------

# TITULO - 
Deixe-nos resolver seus desafios de segurança

## Descricao:
Defendemos e protejemos seus ativos digitais contra ataques maliciosos de adversários.

# SUB - TITULO - 
1 - Nós Arquitetamos
## Descricao:
    E implementamos uma postura geral de segurança cibernética Empresarial.

# SUB - TITULO - 
2 - Nós prevenimos
## Descricao: 
Identificamos e erradicamos ameaças, nos aprofundamos em sua infraestrutura de TI para gerenciar seus riscos, exposição de dados e prevenir ataques antes que eles aconteçam.

# SUB -TITULO - 
3 - Detectamos
## Descricao:
Usamos detecção avançada de ameaças em profundidade com inteligência e caça de ameaças proprietárias.

# SUB - TITULO - 
4 - & Reagimos 24x7
## Descricao:
Você pode se conectar com nossa equipe de Segurança 24x7, ajudamos as organizações no momento de crise, no caso de paralisação, ajudamos as organizações a retornarem às suas atividades no menor tempo possível após um incidente cibernético

-------------------------------
# TITULO - 
Permita-nos combater as ameaças digitais com você
## Descricao:
Fornecemos aos nossos clientes serviços de segurança cibernética de última geração para ajudá-los a entender suas ameaças e combatê-las efetivamente 


# TITULO CARD 1 - 
Defesa Cibernética Empresarial
## Descricao:
Projetamos um ambiente arquitetônico de segurança cibernética empresarial.

# TITULO CARD 2 - 
Teste de Penetração / Avaliação de Vulnerabilidade
## Descricao:
Identificamos proativamente ameaças, vulnerabilidades e riscos de segurança cibernética.

# TITULO CARD 3 - 
Detecção e resposta gerenciadas
## Descricao:
Rastreamos, caçamos e erradicamos ameaças.