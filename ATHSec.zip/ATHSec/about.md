# Somos os Cyber ​​Defenders
Nos colocamos o seu negocio sob nossa proteção


ATHSec ™ é uma empresa sediada em Moçambique, especializada em Consultoria e Gestão de Segurança da Informação Corporativa, somo uma MSP - Managed Security Provider, e trabalhamos para aumentar a resiliência contra a ciberameaças combinando nossas estratégias com seus objetivos de negócio. Estamos 100% focados em segurança cibernética com um MDR 24x7 dedicado a gerenciar e proteger seus dados e redes. As equipes de resposta a incidentes da ATHSec ( Cyber Defenders Incident Response ) fornecem resposta rápida 24h/dia e investigação forense de uma violação.
