# Política Privacidade                    

A sua privacidade é importante para nós. A política de privacidade da ' ATHSec - Information Security Consulting ' respeita a sua privacidade em relação a qualquer informação sua que possamos coletar.
Solicitamos informações pessoais apenas quando realmente precisamos delas para lhe fornecer um serviço. Fazemo-lo por meios justos e legais, com o seu conhecimento e consentimento. Também informamos por que estamos coletando e como será usado.

Apenas retemos as informações coletadas pelo tempo necessário para fornecer o serviço solicitado. Quando armazenamos dados, protegemos dentro de meios comercialmente aceitáveis ​​para evitar perdas e roubos, bem como acesso, divulgação, cópia, uso ou modificação não autorizada.                    

- a) Não compartilhamos informações de identificação pessoal e Coporativa;
- b) Nao compartilhamos nenhum tipo de informacao obtida durante os nossos Testes de Seguranca;
- c) Nossa obrigação é manter os seus dados seguros, aplicando medidas de cibersegurança apropriadas para assegurar a proteção dos seus dados pessoais e impedir o acesso de pessoas não autorizadas; 

# Informações de contato

Para quaisquer dúvidas ou preocupações sobre a política de privacidade, envie um e-mail para info@athsec.org